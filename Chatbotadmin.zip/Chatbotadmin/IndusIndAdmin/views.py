import csv
from datetime import datetime, timedelta
from django.core.paginator import Paginator
from django.db import connection
from django.http import HttpResponse
from django.shortcuts import render, redirect

from .models import AnsweredQueries
from django.db.models import Q

baseURL = "/"
# Create your views here.
def show_answered_queries(request):
    if request.method == "GET":
        print(" --------------------- ans get method ---------------------------- ")

        from_date = request.GET.get('f')
        to_date = request.GET.get('t')

        if from_date == None:
            from_date = ''
        if to_date == None:
            to_date = ''
        print("Answer get data-----", from_date, to_date)

        if (from_date != "" and from_date != None) and (to_date == "" or to_date == None):
            answered_query = AnsweredQueries.objects.filter(asked_on__date=from_date).order_by('-query_id')

        elif (to_date != "" and to_date != None) and (from_date == "" or from_date == None):
            answered_query = AnsweredQueries.objects.filter(asked_on__date=to_date).order_by('-query_id')

        elif (from_date != "" and to_date != "") and (from_date != None and to_date != None):
            to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()
            # toDate = to_dt + timedelta(days=1)
            # to = toDate.strftime("%Y-%m-%d")
            # print("get method new==", to)
            answered_query = AnsweredQueries.objects.filter(asked_on__date__gte=from_date,
                                                                asked_on__date__lte=to_dt).order_by('-query_id')
        else:
            answered_query = AnsweredQueries.objects.all().order_by('-query_id')

        print("get ans qyery----> ", answered_query)
        datalength = len(answered_query)
        print("ans datalen---->", datalength)
        if len(answered_query) > 0:
            paginator = Paginator(answered_query, 10)
            page = request.GET.get('page')
            print(" get mthd page==", page)
            answered_query = paginator.get_page(page)

            return render(request, "IndusIndAdmin/answered.html",
                          {'answered_query': answered_query, 'from': from_date, 'to': to_date,
                           'datalength': datalength,
                           'message': '', 'baseURL': baseURL})
        else:
            return render(request, "IndusIndAdmin/answered.html",
                          {'message': 'No Data Found!', 'from': from_date, 'to': to_date, 'datalength': datalength,
                           'baseURL': baseURL})

    if request.method == 'POST':
        print(" --------------------- ans post method ---------------------------- ")

        from_date = request.POST.get('from_date')
        to_date = request.POST.get('to_date')

        # location = request.POST.get('loc')
        # print("post fun loc==> ", location)
        if from_date == None:
            from_date = ''
        if to_date == None:
            to_date = ''
        # location = request.POST.get('loc')
        #
        # if location == '' or location == None or location == 'All':
        #     location = 'All'
        print("post mthd answered date==", from_date, to_date)

        if (from_date != "" and from_date != None) and (to_date == "" or to_date == None):
            print("post from date")
            answered_query = AnsweredQueries.objects.filter(asked_on__date=from_date).order_by('-query_id')


        elif (to_date != "" and to_date != None) and (from_date == "" or from_date == None):
            print("post to date")
            answered_query = AnsweredQueries.objects.filter(asked_on__date=to_date).order_by('-query_id')

        elif (from_date != "" and to_date != "") and (from_date != None and to_date != None):
            print("post both date")
            to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()
            # toDate = to_dt + timedelta(days=1)
            # to = toDate.strftime("%Y-%m-%d")
            # print("post mthd new==", to)
            answered_query = AnsweredQueries.objects.filter(asked_on__date__gte=from_date,
                                                            asked_on__date__lte=to_dt).order_by('-query_id')

        else:
            print("post both none")
            answered_query = AnsweredQueries.objects.all().order_by('-query_id')

        print("post mthd ans query----> ", answered_query)
        datalength = len(answered_query)
        print("ans datalen---->", datalength)
        if len(answered_query) > 0:
            paginator = Paginator(answered_query, 10)
            page = request.GET.get('page')
            # print("post mthd page==", page)
            answered_query = paginator.get_page(page)
            print("post--->", answered_query, from_date)
            return render(request, "IndusIndAdmin/answered.html",
                          {'answered_query': answered_query, 'from': from_date, 'to': to_date,
                           'datalength': datalength, 'message': '', 'baseURL': baseURL})
        else:
            return render(request, "IndusIndAdmin/answered.html",
                          {'message': 'No Data Found!', 'from': from_date, 'to': to_date,
                           'datalength': datalength, 'baseURL': baseURL})

def search_data(request):
    if request.method == "GET":
        url_parameter = request.GET.get('searchtext')
        print("param==", url_parameter)

    if url_parameter != "":
        answered_query = AnsweredQueries.objects.filter(
            Q(query__icontains=url_parameter) | Q(username__icontains=url_parameter) | Q(
                category__icontains=url_parameter) | Q(userid__icontains=url_parameter)).order_by('-query_id')
    else:
        answered_query = AnsweredQueries.objects.all().order_by('-query_id')
    print("ans==", answered_query)
    datalength = len(answered_query)
    if len(answered_query) > 0:
        paginator = Paginator(answered_query, 10)
        print(paginator)
        page = request.GET.get('page')
        print("==", page)
        answered_query = paginator.get_page(page)

        print("search===>", answered_query)
        return render(request, "IndusIndAdmin/answered.html",
                      {'answered_query': answered_query, 'message': '', 'search': url_parameter, 'baseURL': baseURL,'datalength': datalength})
    else:
        return render(request, "IndusIndAdmin/answered.html",
                      {'message': 'No Data Found!', 'search': url_parameter, 'baseURL': baseURL})

def AnsweredCSV(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="AnsweredQuery.csv"'
    q = "SELECT query,asked_on,username,category,Feedback,userid,rating,rating_feedback FROM answered_queries"
    cursor = connection.cursor()
    cursor.execute(q)
    employees1 = cursor.fetchall()
    writer = csv.writer(response)
    csv_count = 0
    writer.writerow(
        ['Sr.', 'Query', 'Created At', 'UserName', 'Category', 'Issue Resolved', 'UserID', 'Rating',
         'Rating Feedback'])
    for employe in employees1:
        csv_count += 1
        e_12 = list(employe)
        e_12.insert(0, csv_count)
        new_arr = tuple(e_12)
        # print("--------------", new_arr)
        writer.writerow(new_arr)

    return response

def deleteAnswerData(request, id):
    query = AnsweredQueries.objects.get(query_id=id)
    cursor = connection.cursor()
    cursor.execute("select query from answered_queries where query_id= '" + str(id) + "' ")
    ansquery = cursor.fetchone()[0]
    query.delete()
    # activityLogs(request, "Answered query deleted: " + ansquery, "Answered Queries")
    return redirect(baseURL + 'answer')

