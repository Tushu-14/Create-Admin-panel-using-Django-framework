from django.apps import AppConfig


class IndusindadminConfig(AppConfig):
    name = 'IndusIndAdmin'
