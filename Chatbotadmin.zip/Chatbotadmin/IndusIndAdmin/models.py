from django.db import models

# Create your models here.
class survey_bot(models.Model):
    SURVEY_ID = models.AutoField(primary_key=True)
    TITLE = models.CharField(max_length=500)
    START_DATE = models.DateField()
    END_DATE = models.DateField()
    STATUS = models.CharField(max_length=500)
    INITIATE_BY = models.CharField(max_length=500)
    # flag = models.CharField(max_length=200)
    # value = models.CharField(max_length=1000)


    def __str__(self):
        return self.TITLE

    class Meta:
        managed = False
        db_table = "survey_bot"

class surveydetails(models.Model):
    SURVEY_ID = models.IntegerField(max_length=50)
    QUESTION_ID	= models.AutoField(primary_key=True)
    QUESTION = models.CharField(max_length=10000)
    TYPE = models.CharField(max_length=500)
    OPTIONS = models.CharField(max_length=500)
    STATUS = models.CharField(max_length=255)

    def __str__(self):
        return self.QUESTION

    class Meta:
        managed = False
        db_table = "survey_details"

class survey_submit_details(models.Model):
    ID = models.AutoField(primary_key=True)
    EMP_ID = models.IntegerField(max_length=50)
    SURVEY_ID = models.IntegerField(max_length=50)
    QUESTION_ID = models.CharField(max_length=255)
    ANSWER = models.CharField(max_length=1000)
    SUBMITTED_DATE = models.DateField()
    EMP_NAME = models.CharField(max_length=255)
    # flag = models.CharField(max_length=200)
    # value = models.CharField(max_length=1000)


    class Meta:
        managed = False
        db_table = "survey_submit_details"


# Create your models here.
class AnsweredQueries(models.Model):
    query_id = models.AutoField(primary_key=True)
    query = models.CharField(max_length=1000)
    userid = models.IntegerField()
    username = models.CharField(max_length=255)
    userType =  models.CharField(max_length=20)
    feedback = models.CharField(max_length=10)
    category = models.CharField(max_length=50)
    status = models.CharField(max_length=100)
    asked_on = models.DateTimeField()
    rating = models.IntegerField()
    rating_feedback = models.CharField(max_length=255)
    location = models.CharField(max_length=500)

    def __str__(self):
        return self.query

    class Meta:
        managed = False
        db_table = "answered_queries"

class UnansweredQueries(models.Model):
    query_id = models.AutoField(primary_key=True)
    query = models.CharField(max_length=1000)
    username = models.CharField(max_length=255)
    userType = models.CharField(max_length=20)
    category = models.CharField(max_length=50)
    status = models.CharField(max_length=100)
    asked_on = models.DateTimeField()

    def __str__(self):
        return self.query

    class Meta:
        managed = False
        db_table = "unanswered_queries"

class ManageDocument(models.Model):
    doc_id = models.AutoField(primary_key=True)
    doc_title = models.CharField(max_length=1000)
    doc_desc = models.CharField(max_length=10000)
    sender = models.CharField(max_length=100)
    date = models.DateField()
    Attachment = models.CharField(max_length=500, blank=True, null=True)
    doc_status = models.CharField(max_length=20,default='Active')
    flag = models.CharField(max_length=100)
    value = models.CharField(max_length=1000)

    def __str__(self):
        return self.doc_title

    class Meta:
        managed = False
        db_table = "manage_document"
